<?

$UserId = "xxxxx";
$Token = "xxxxx";
$Uuid = "xxxxx";